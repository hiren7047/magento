<?php

class Hk_Brand_Helper_Brand extends Mage_Core_Helper_Abstract
{

	public function __construct()
	{
	}
}
