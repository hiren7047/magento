<?php

class Ccc_Category_Model_Category extends Mage_Core_Model_Abstract
{
    function __construct()
    {
        $this->_init('category/category');
    }
}
