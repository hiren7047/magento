<?php

class Ccc_Category_Helper_Data extends Mage_Core_Helper_Abstract
{

	public function __construct()
	{
	}
}
